import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: ['.a{color:blue;}']
})
export class AppComponent {
  title = 'Marvellous Infosystems';
}
